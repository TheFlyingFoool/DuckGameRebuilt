﻿//// Decompiled with JetBrains decompiler
//// Type: DuckGame.ParentalControls
////removed for regex reasons Culture=neutral, PublicKeyToken=null
//// MVID: C907F20B-C12B-4773-9B1E-25290117C0E4
//// Assembly location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.exe
//// XML documentation location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.xml

//namespace DuckGame
//{
//    internal static class ParentalControls
//    {
//        //private static bool hasCheckedParentalControls;
//        //private static bool cachedAreParentalControlsActive;

//        //public static void TestMethod()
//        //{
//        //    string inOutTextToCheck = "fu*c????k! this is a badf*(*(ucking phrase.";
//        //    ParentalControls.GetLatestProfanityOutputString();
//        //    ParentalControls.RunProfanityCheck(ref inOutTextToCheck);
//        //    ParentalControls.GetLatestProfanityOutputString();
//        //}

//        public static int RunProfanityCheck(ref string inOutTextToCheck) => 0;

//       // public static string GetLatestProfanityOutputString() => "";

//        public static bool AreParentalControlsActive(bool bRestrictionsUI = false) => false;

//        //public static void TryOpenParentalControlsWarning()
//        //{
//        //}
//    }
//}
