﻿//// Decompiled with JetBrains decompiler
//// Type: DuckGame.CrashLogRoom
////removed for regex reasons Culture=neutral, PublicKeyToken=null
//// MVID: C907F20B-C12B-4773-9B1E-25290117C0E4
//// Assembly location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.exe
//// XML documentation location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.xml

//namespace DuckGame
//{
//    internal class CrashLogRoom : Level
//    {
//        private FancyBitmapFont _font = new FancyBitmapFont("smallFont");
//        private string _error;

//        public CrashLogRoom(string error)
//        {
//            this._error = error;
//            this._centeredView = true;
//        }

//        public override void Initialize()
//        {
//            this._startCalled = true;
//            base.Initialize();
//        }

//        public override void Draw()
//        {
//            this._font.scale = new Vec2(0.5f, 0.5f);
//            this._font.Draw(this._error, new Vec2(30f, 30f), Color.White);
//        }
//    }
//}
