﻿// Decompiled with JetBrains decompiler
// Type: DuckGame.DataLayer
//removed for regex reasons Culture=neutral, PublicKeyToken=null
// MVID: C907F20B-C12B-4773-9B1E-25290117C0E4
// Assembly location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.exe
// XML documentation location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.xml

namespace DuckGame
{
    public class DataLayer
    {
        protected NCNetworkImplementation _impl;

        public DataLayer(NCNetworkImplementation pImpl) => _impl = pImpl;

        public virtual NCError SendPacket(BitBuffer sendData, NetworkConnection connection) => _impl.OnSendPacket(sendData.buffer, sendData.lengthInBytes, connection.data);

        public virtual void Update()
        {
        }

        public virtual void EndSession()
        {
        }

        public virtual void Reset()
        {
        }
    }
}
