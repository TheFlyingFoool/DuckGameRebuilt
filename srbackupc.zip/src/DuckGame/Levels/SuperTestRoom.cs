﻿//// Decompiled with JetBrains decompiler
//// Type: DuckGame.SuperTestRoom
////removed for regex reasons Culture=neutral, PublicKeyToken=null
//// MVID: C907F20B-C12B-4773-9B1E-25290117C0E4
//// Assembly location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.exe
//// XML documentation location: D:\Program Files (x86)\Steam\steamapps\common\Duck Game\DuckGame.xml

//namespace DuckGame
//{
//    public class SuperTestRoom : Level
//    {
//        private Sprite _sprite;

//        public override void Initialize()
//        {
//            this._sprite = new Sprite("happyman");
//            base.Initialize();
//        }

//        public override void Update()
//        {
//        }

//        public override void PostDrawLayer(Layer layer)
//        {
//            if (layer != Layer.Game)
//                return;
//            Graphics.Draw(this._sprite, 10f, 10f);
//        }
//    }
//}
